"""State machine models."""

from dataclasses import dataclass, field
from typing import List, Optional

from eth_typing import HexStr


@dataclass
class State:
    """A state in the inferred state machine."""

    name: str
    description: str
    entering_functions: List[str] = field(default_factory=list)
    exiting_functions: List[str] = field(default_factory=list)
    storage_fingerprint: Optional[Dict[str, str]] = None  # key storage values
    is_implicit: bool = False  # Not obvious from code alone


@dataclass
class Transition:
    """A transition between states."""

    from_state: str
    to_state: str
    trigger: str  # Function name or event
    guard_condition: Optional[str] = None
    confidence: float = 1.0
    evidence_txs: List[HexStr] = field(default_factory=list)
    frequency: float = 0.0  # % of transactions showing this transition


@dataclass
class StateMachine:
    """Inferred finite state machine."""

    contract_address: str
    states: List[State] = field(default_factory=list)
    transitions: List[Transition] = field(default_factory=list)
    initial_state: Optional[str] = None
    unreachable_states: List[str] = field(default_factory=list)
    unexpectedly_reachable: List[str] = field(default_factory=list)
