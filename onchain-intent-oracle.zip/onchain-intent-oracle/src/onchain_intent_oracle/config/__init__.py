"""Configuration module."""
