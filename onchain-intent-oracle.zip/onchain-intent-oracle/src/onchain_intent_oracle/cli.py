"""Command-line interface for OnChainIntentOracle."""

import asyncio
from pathlib import Path
from typing import Optional

import structlog
import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from onchain_intent_oracle.config.settings import get_settings

app = typer.Typer(
    name="oio",
    help="OnChainIntentOracle: Extract observed behavior from EVM contracts",
    no_args_is_help=True,
)
console = Console()
logger = structlog.get_logger()


@app.command()
def analyze(
    contract_address: str = typer.Argument(..., help="Contract address to analyze"),
    chain: str = typer.Option("ethereum", "--chain", "-c", help="Chain name or chain ID"),
    rpc_url: Optional[str] = typer.Option(None, "--rpc-url", help="Custom RPC URL"),
    block_range: Optional[str] = typer.Option(None, "--block-range", help="Block range as start:end"),
    design_doc: Optional[Path] = typer.Option(None, "--design-doc", help="Existing design document"),
    threat_model: Optional[Path] = typer.Option(None, "--threat-model", help="Threat model document"),
    output_dir: Path = typer.Option(Path("./oio-output"), "--output", "-o", help="Output directory"),
    depth: str = typer.Option("standard", "--depth", help="Analysis depth: quick|standard|deep"),
    max_bug_rounds: int = typer.Option(3, "--max-bug-rounds", help="Bug hunting rounds"),
    cache_ns: str = typer.Option("default", "--cache-ns", help="Cache namespace"),
):
    """Analyze a deployed contract and generate observed design artifacts."""

    settings = get_settings()

    console.print(f"[bold blue]OnChainIntentOracle[/bold blue] analyzing {contract_address}")
    console.print(f"Chain: {chain} | Depth: {depth} | Output: {output_dir}")

    # Resolve chain ID
    from onchain_intent_oracle.config.chains import get_chain_config_by_name
    try:
        chain_config = get_chain_config_by_name(chain)
        chain_id = chain_config.chain_id
    except ValueError:
        chain_id = int(chain)

    # Parse block range
    if block_range:
        parts = block_range.split(":")
        from_block = int(parts[0])
        to_block = int(parts[1]) if len(parts) > 1 else from_block + 1000
    else:
        from_block = 18000000
        to_block = from_block + 1000

    # Create output directory
    output_dir.mkdir(parents=True, exist_ok=True)

    # Run async pipeline
    try:
        asyncio.run(_run_analysis(
            contract_address=contract_address,
            chain_id=chain_id,
            from_block=from_block,
            to_block=to_block,
            design_doc_path=design_doc,
            threat_model_path=threat_model,
            output_dir=output_dir,
            depth=depth,
            rpc_url=rpc_url,
        ))
    except Exception as e:
        logger.error("analysis_failed", error=str(e))
        console.print(f"[red]Analysis failed: {e}[/red]")
        raise typer.Exit(1)

    console.print("[green]Analysis complete![/green]")
    console.print(f"Results written to: {output_dir}")
    console.print("")
    console.print("Artifacts generated:")
    console.print("  - observed_design.md (narrative design document)")
    console.print("  - observed_design.json (structured analysis data)")
    console.print("  - conflict_report.md (design vs reality gaps)")
    console.print("  - visualizations/ (state diagrams, call graphs)")
    console.print("")
    console.print("Use these as inputs to AutoProver or other FV tools.")


async def _run_analysis(
    contract_address: str,
    chain_id: int,
    from_block: int,
    to_block: int,
    design_doc_path: Optional[Path],
    threat_model_path: Optional[Path],
    output_dir: Path,
    depth: str,
    rpc_url: Optional[str],
):
    """Run the full analysis pipeline."""
    from onchain_intent_oracle.ingestion.rpc_manager import RPCManager
    from onchain_intent_oracle.ingestion.cache import CacheLayer
    from onchain_intent_oracle.ingestion.proxy_detector import ProxyDetector
    from onchain_intent_oracle.ingestion.source_resolver import SourceResolver
    from onchain_intent_oracle.analysis.state_machine import StateMachineInference
    from onchain_intent_oracle.analysis.invariant_miner import InvariantMiner
    from onchain_intent_oracle.analysis.pattern_clustering import PatternClustering
    from onchain_intent_oracle.analysis.anomaly_detector import AnomalyDetector
    from onchain_intent_oracle.analysis.conflict_reconciler import ConflictReconciler
    from onchain_intent_oracle.output.markdown_generator import MarkdownGenerator
    from onchain_intent_oracle.output.json_generator import JSONGenerator
    from onchain_intent_oracle.output.conflict_report import ConflictReportGenerator
    from onchain_intent_oracle.output.visualizer import Visualizer

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:

        # 1. Initialize infrastructure
        task = progress.add_task("Initializing...", total=None)

        urls = [rpc_url] if rpc_url else []
        rpc = RPCManager(urls=urls)
        cache = CacheLayer()
        proxy_detector = ProxyDetector(rpc)
        source_resolver = SourceResolver()

        progress.update(task, description="Fetching contract info...")

        # 2. Detect proxy and get implementation
        is_proxy, impl, proxy_type = await proxy_detector.detect_proxy(contract_address)
        target_address = impl if impl else contract_address

        # 3. Get ABI and source code
        abi = await source_resolver.get_abi(target_address, chain_id)
        source_code = await source_resolver.get_source_code(target_address, chain_id)

        # 4. Fetch transaction logs (events)
        progress.update(task, description=f"Fetching logs from block {from_block} to {to_block}...")
        logs = await rpc.get_logs(from_block, to_block, address=contract_address)

        # 5. Build transaction list from logs (simplified)
        # In a full implementation, we'd fetch full tx receipts and traces
        from onchain_intent_oracle.models.transaction import Transaction
        from datetime import datetime
        from decimal import Decimal

        transactions = []
        for log in logs[:100]:  # Limit for quick mode
            tx = Transaction(
                hash=log.get("transactionHash", "0x"),
                block_number=int(log.get("blockNumber", "0x0"), 16),
                timestamp=datetime.now(),
                from_address=log.get("address", "0x"),
                to_address=contract_address,
                value=Decimal("0"),
                logs=[log],
            )
            transactions.append(tx)

        progress.update(task, description=f"Analyzing {len(transactions)} transactions...")

        # 6. Run deterministic analysis
        sm_inference = StateMachineInference()
        state_machine = sm_inference.infer(transactions)

        inv_miner = InvariantMiner()
        invariants = inv_miner.mine(transactions)

        pattern_cluster = PatternClustering()
        patterns = pattern_cluster.cluster(transactions)

        anomaly_detector = AnomalyDetector()
        anomalies = anomaly_detector.detect(transactions)

        # 7. Load design doc if provided
        design_doc_text = None
        if design_doc_path and design_doc_path.exists():
            design_doc_text = design_doc_path.read_text()

        # 8. Reconcile conflicts
        reconciler = ConflictReconciler(design_doc=design_doc_text)
        conflicts = reconciler.reconcile(transactions, invariants, source_code)

        # 9. Generate outputs
        progress.update(task, description="Generating outputs...")

        analysis_data = {
            "contract_address": contract_address,
            "chain_id": chain_id,
            "block_range": (from_block, to_block),
            "tx_count": len(transactions),
            "contract_type": "token" if abi and any(f.get("name") == "transfer" for f in abi if isinstance(f, dict)) else "unknown",
            "standards": ["ERC20"] if abi and any(f.get("name") == "transfer" for f in abi if isinstance(f, dict)) else [],
            "state_machine": {
                "states": [{"name": s.name, "description": s.description, "is_implicit": s.is_implicit} for s in state_machine.states],
                "transitions": [{"from": t.from_state, "to": t.to_state, "trigger": t.trigger, "guard": t.guard_condition} for t in state_machine.transitions],
            },
            "invariants": [{"id": i.id, "expression": i.expression, "type": i.type.value, "confidence": i.confidence, "evidence": i.evidence} for i in invariants],
            "patterns": patterns,
            "anomalies": anomalies,
            "conflicts": {
                "conflicts": [{"severity": c.severity, "category": c.category, "design_claim": c.design_claim, "observed_reality": c.observed_reality, "recommendation": c.recommendation} for c in conflicts.conflicts],
                "omissions": conflicts.omissions,
                "weakenings": conflicts.weakenings,
                "security_gaps": conflicts.security_gaps,
            },
            "evidence_txs": [{"hash": tx.hash, "block": tx.block_number, "description": tx.method_name or "unknown"} for tx in transactions[:10]],
            "high_confidence_invariants": [{"id": i.id, "expression": i.expression, "confidence": i.confidence, "cvl_template": i.fv_template_hint, "evidence": i.evidence} for i in invariants if i.confidence >= 0.95],
            "medium_confidence_invariants": [{"id": i.id, "expression": i.expression, "confidence": i.confidence} for i in invariants if 0.8 <= i.confidence < 0.95],
            "common_patterns": patterns.get("common_patterns", []),
            "rare_patterns": patterns.get("rare_patterns", []),
            "overview": f"Contract {contract_address} on chain {chain_id} analyzed from block {from_block} to {to_block}.",
            "security_notes": f"Proxy: {proxy_type}, Implementation: {impl or 'N/A'}",
        }

        # Write outputs
        (output_dir / "observed_design.md").write_text(MarkdownGenerator.generate(analysis_data))
        (output_dir / "observed_design.json").write_text(JSONGenerator.generate(analysis_data))
        (output_dir / "conflict_report.md").write_text(ConflictReportGenerator.generate(analysis_data))

        # Visualizations
        viz_dir = output_dir / "visualizations"
        viz_dir.mkdir(exist_ok=True)
        (viz_dir / "state_machine.mmd").write_text(Visualizer.generate_state_diagram_mermaid(state_machine))
        (viz_dir / "call_graph.mmd").write_text(Visualizer.generate_call_graph_mermaid([{"from_address": tx.from_address, "method_name": tx.method_name} for tx in transactions]))

        progress.update(task, description="Done!")


@app.command()
def report(
    run_id: str = typer.Argument(..., help="Analysis run ID"),
    format: str = typer.Option("markdown", "--format", help="Output format: markdown|json|html"),
):
    """Generate a report from a previous analysis run."""
    console.print(f"Generating {format} report for run {run_id}")


@app.command()
def index_kb(
    docs_dir: Path = typer.Argument(..., help="Directory of documents to index"),
):
    """Index documents into the RAG knowledge base."""
    console.print(f"Indexing documents from {docs_dir}")
    # TODO: Load documents, chunk, embed, store


def main():
    """Entry point."""
    app()


if __name__ == "__main__":
    main()
