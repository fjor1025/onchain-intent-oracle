"""Infer finite state machines from observed transaction sequences."""

from collections import defaultdict
from typing import Dict, List, Optional, Set, Tuple

import structlog

from onchain_intent_oracle.models.state_machine import State, StateMachine, Transition
from onchain_intent_oracle.models.transaction import Transaction

logger = structlog.get_logger()


class StateMachineInference:
    """Builds an observed state machine from transaction history."""

    def __init__(self):
        self.states: Dict[str, State] = {}
        self.transitions: List[Transition] = []
        self._state_sequences: Dict[str, List[str]] = defaultdict(list)
        self._storage_fingerprints: Dict[str, Dict[str, str]] = defaultdict(dict)

    def _compute_storage_fingerprint(self, tx: Transaction) -> str:
        """Create a hash of storage changes to identify states."""
        if not tx.state_diffs:
            return "default"

        # Group by slot, track if value increased/decreased/unchanged
        changes = []
        for diff in tx.state_diffs:
            if diff.new_value and diff.old_value:
                if int(diff.new_value, 16) > int(diff.old_value, 16):
                    changes.append(f"{diff.slot}:inc")
                elif int(diff.new_value, 16) < int(diff.old_value, 16):
                    changes.append(f"{diff.slot}:dec")
                else:
                    changes.append(f"{diff.slot}:eq")
            else:
                changes.append(f"{diff.slot}:set")

        return "|".join(sorted(changes)) if changes else "default"

    def _identify_implicit_states(self, txs: List[Transaction]) -> List[State]:
        """Identify behaviorally distinct modes not obvious from code."""
        # Cluster by: paused/unpaused, emergency mode, etc.
        state_groups = defaultdict(list)

        for tx in txs:
            fp = self._compute_storage_fingerprint(tx)
            state_groups[fp].append(tx)

        states = []
        for fp, group in state_groups.items():
            if len(group) < 5:  # Too few samples
                continue

            # Infer state name from dominant behavior
            methods = [tx.method_name for tx in group if tx.method_name]
            dominant = max(set(methods), key=methods.count) if methods else "unknown"

            state = State(
                name=f"state_{fp[:16]}",
                description=f"Mode where {dominant} is dominant ({len(group)} txs)",
                entering_functions=list(set(
                    tx.method_name for tx in group if tx.method_name
                )),
                is_implicit=True,
                storage_fingerprint=dict(
                    (diff.slot, diff.new_value) 
                    for tx in group 
                    for diff in tx.state_diffs
                ),
            )
            states.append(state)

        return states

    def infer(self, txs: List[Transaction]) -> StateMachine:
        """Infer state machine from transaction list."""
        if not txs:
            return StateMachine(contract_address="unknown")

        contract = txs[0].to_address or "unknown"

        # Sort by block number/timestamp
        sorted_txs = sorted(txs, key=lambda t: (t.block_number, t.hash))

        # Build state sequence
        current_state = "initial"
        state_sequence = [current_state]

        for tx in sorted_txs:
            fp = self._compute_storage_fingerprint(tx)
            next_state = f"state_{fp[:16]}"

            if next_state != current_state:
                # Record transition
                guard = None
                if tx.method_name:
                    guard = f"{tx.method_name}() called by {tx.from_address[:10]}..."

                self.transitions.append(Transition(
                    from_state=current_state,
                    to_state=next_state,
                    trigger=tx.method_name or "unknown",
                    guard=guard,
                    evidence_txs=[tx.hash],
                ))
                current_state = next_state

            state_sequence.append(current_state)

        # Identify implicit states
        implicit = self._identify_implicit_states(txs)

        # Build explicit states from transitions
        state_names = set()
        for t in self.transitions:
            state_names.add(t.from_state)
            state_names.add(t.to_state)

        explicit_states = [
            State(name=s, description=f"Observed state {s}")
            for s in state_names
        ]

        # Merge with implicit
        all_states = explicit_states + implicit

        # Compute transition frequencies
        transition_counts = defaultdict(int)
        for t in self.transitions:
            key = (t.from_state, t.to_state, t.trigger)
            transition_counts[key] += 1

        total = len(self.transitions)
        for t in self.transitions:
            key = (t.from_state, t.to_state, t.trigger)
            t.frequency = transition_counts[key] / total if total > 0 else 0

        # Detect unreachable and unexpectedly reachable
        reachable = set(t.to_state for t in self.transitions)
        reachable.add("initial")
        all_state_names = set(s.name for s in all_states)
        unreachable = all_state_names - reachable

        # States reachable but never exited (sinks)
        exited = set(t.from_state for t in self.transitions)
        sinks = reachable - exited

        return StateMachine(
            contract_address=contract,
            states=all_states,
            transitions=self.transitions,
            initial_state="initial",
            unreachable_states=list(unreachable),
            unexpectedly_reachable=list(sinks),
        )
