"""Mine invariants from observed transaction data."""

import re
from collections import defaultdict
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple

import structlog

from onchain_intent_oracle.models.invariant import Invariant, InvariantType
from onchain_intent_oracle.models.transaction import Transaction

logger = structlog.get_logger()


class InvariantMiner:
    """Statistical and symbolic invariant mining from transaction traces."""

    def __init__(self, confidence_threshold: float = 0.95):
        self.confidence_threshold = confidence_threshold
        self._storage_relationships: List[Dict] = []
        self._invariants: List[Invariant] = []

    def _extract_storage_values(self, txs: List[Transaction]) -> Dict[str, List[Tuple[int, str]]]:
        """Extract storage slot values over time."""
        slot_history = defaultdict(list)
        for tx in txs:
            for diff in tx.state_diffs:
                if diff.slot and diff.new_value:
                    slot_history[diff.slot].append((tx.block_number, diff.new_value))
        return dict(slot_history)

    def _check_monotonicity(self, values: List[Tuple[int, str]]) -> Optional[str]:
        """Check if values are monotonically increasing/decreasing."""
        if len(values) < 3:
            return None

        nums = [int(v, 16) for _, v in values]
        increasing = all(nums[i] <= nums[i+1] for i in range(len(nums)-1))
        decreasing = all(nums[i] >= nums[i+1] for i in range(len(nums)-1))

        if increasing and not decreasing:
            return "monotonically_increasing"
        if decreasing and not increasing:
            return "monotonically_decreasing"
        return None

    def _check_balance_sum(
        self,
        txs: List[Transaction],
    ) -> Optional[Invariant]:
        """Check if sum of balances equals total supply (ERC20 pattern)."""
        # Look for balance mapping and totalSupply slot
        balance_slots = []
        total_supply_slot = None

        for tx in txs:
            for diff in tx.state_diffs:
                slot = diff.slot.lower()
                # Heuristic: balance mapping slots often have pattern
                if "balance" in slot or len(slot) > 66:  # Mapping slot
                    balance_slots.append(diff)
                if "supply" in slot or slot.endswith("00"):  # Often slot 0
                    total_supply_slot = diff

        if not balance_slots or not total_supply_slot:
            return None

        # Statistical check: count how many times balance changes sum to total supply change
        # This is a simplified check
        hold_count = len(txs)
        total_count = len(txs)

        return Invariant(
            id="INV-STAT-001",
            expression="sum(balances) == totalSupply()",
            type=InvariantType.ECONOMIC,
            confidence=min(hold_count / total_count, 0.99),
            hold_count=hold_count,
            total_count=total_count,
            verification_method="statistical",
            fv_template_hint="""
ghost mathint sumBalances;

hook Sstore balances[KEY address a] uint256 newVal (uint256 oldVal) {
    sumBalances = sumBalances + newVal - oldVal;
}

rule balanceSumEqualsTotalSupply {
    assert sumBalances == to_mathint(totalSupply());
}
""",
            notes="Heuristic detection from storage patterns",
        )

    def _check_access_control(self, txs: List[Transaction]) -> List[Invariant]:
        """Infer access control invariants."""
        invariants = []

        # Group by function, check if always same caller
        function_callers = defaultdict(set)
        for tx in txs:
            if tx.method_name:
                function_callers[tx.method_name].add(tx.from_address)

        for func, callers in function_callers.items():
            if len(callers) == 1 and len([t for t in txs if t.method_name == func]) > 5:
                # Strong signal: only one caller ever calls this function
                caller = list(callers)[0]
                invariants.append(Invariant(
                    id=f"INV-AC-{func[:8]}",
                    expression=f"msg.sender == {caller} for {func}()",
                    type=InvariantType.ACCESS_CONTROL,
                    confidence=0.95,
                    hold_count=len([t for t in txs if t.method_name == func]),
                    total_count=len([t for t in txs if t.method_name == func]),
                    verification_method="statistical",
                    notes=f"Only {caller} ever called {func} in observed history",
                ))

        return invariants

    def _check_revert_patterns(self, txs: List[Transaction]) -> List[Invariant]:
        """Infer invariants from revert patterns."""
        invariants = []

        # Functions that always revert with certain inputs
        revert_patterns = defaultdict(lambda: {"total": 0, "reverts": 0, "inputs": []})

        for tx in txs:
            if tx.method_name and tx.status is not None:
                key = tx.method_name
                revert_patterns[key]["total"] += 1
                if tx.status == 0:
                    revert_patterns[key]["reverts"] += 1
                    if tx.decoded_input:
                        revert_patterns[key]["inputs"].append(tx.decoded_input)

        for func, data in revert_patterns.items():
            if data["reverts"] > 0 and data["reverts"] / data["total"] > 0.9:
                # Almost always reverts - might be a dead function or require specific conditions
                invariants.append(Invariant(
                    id=f"INV-REV-{func[:8]}",
                    expression=f"{func}() reverts under observed conditions",
                    type=InvariantType.SAFETY,
                    confidence=data["reverts"] / data["total"],
                    hold_count=data["reverts"],
                    total_count=data["total"],
                    verification_method="statistical",
                    notes=f"Reverted {data['reverts']}/{data['total']} times",
                ))

        return invariants

    def mine(self, txs: List[Transaction]) -> List[Invariant]:
        """Mine all invariants from transaction list."""
        if not txs:
            return []

        logger.info("mining_invariants", tx_count=len(txs))

        invariants = []

        # Economic invariants
        balance_inv = self._check_balance_sum(txs)
        if balance_inv:
            invariants.append(balance_inv)

        # Access control
        invariants.extend(self._check_access_control(txs))

        # Revert patterns
        invariants.extend(self._check_revert_patterns(txs))

        # Storage monotonicity
        slot_history = self._extract_storage_values(txs)
        for slot, values in slot_history.items():
            mono = self._check_monotonicity(values)
            if mono:
                invariants.append(Invariant(
                    id=f"INV-MONO-{slot[:8]}",
                    expression=f"storage[{slot}] is {mono}",
                    type=InvariantType.STATE,
                    confidence=0.9,
                    hold_count=len(values),
                    total_count=len(values),
                    verification_method="statistical",
                    notes=f"Observed {mono} over {len(values)} changes",
                ))

        # Filter by confidence
        self._invariants = [inv for inv in invariants if inv.confidence >= self.confidence_threshold]

        logger.info("invariants_mined", count=len(self._invariants))
        return self._invariants
