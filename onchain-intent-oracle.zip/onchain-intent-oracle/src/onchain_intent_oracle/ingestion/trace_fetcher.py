"""Fetch and parse transaction traces with state diffs."""

from typing import Any, Dict, List, Optional

import structlog
from eth_typing import ChecksumAddress, HexStr

from onchain_intent_oracle.ingestion.cache import CacheLayer
from onchain_intent_oracle.ingestion.rpc_manager import RPCManager
from onchain_intent_oracle.models.transaction import CallTrace, StateDiff, Transaction

logger = structlog.get_logger()


class TraceFetcher:
    """Fetches and parses transaction traces."""

    def __init__(self, rpc: RPCManager, cache: Optional[CacheLayer] = None):
        self.rpc = rpc
        self.cache = cache or CacheLayer()

    async def fetch_trace(self, tx_hash: str, chain_id: int = 1) -> Optional[Dict]:
        """Fetch trace with caching."""
        cached = self.cache.get_tx_trace(chain_id, tx_hash)
        if cached:
            logger.debug("trace_cache_hit", tx_hash=tx_hash)
            return cached

        # Try debug_traceTransaction with callTracer first
        try:
            trace = await self.rpc.debug_trace_transaction(
                tx_hash,
                tracer="callTracer",
                tracer_config={"withLog": True},
            )
            if trace:
                self.cache.set_tx_trace(chain_id, tx_hash, trace)
                return trace
        except Exception as e:
            logger.warning("debug_trace_failed", tx_hash=tx_hash, error=str(e))

        # Fallback to trace_transaction (Parity style)
        try:
            trace = await self.rpc.trace_transaction(tx_hash)
            if trace:
                self.cache.set_tx_trace(chain_id, tx_hash, trace)
                return trace
        except Exception as e:
            logger.warning("trace_transaction_failed", tx_hash=tx_hash, error=str(e))

        return None

    async def fetch_state_diff(
        self,
        tx_hash: str,
        chain_id: int = 1,
    ) -> List[StateDiff]:
        """Fetch state differences for a transaction."""
        # Use debug_traceTransaction with prestateTracer + diff mode
        try:
            trace = await self.rpc.debug_trace_transaction(
                tx_hash,
                tracer="prestateTracer",
                tracer_config={"diffMode": True},
            )
            if trace and "post" in trace:
                diffs = []
                for addr, state in trace["post"].items():
                    for slot, value in state.get("storage", {}).items():
                        diffs.append(StateDiff(
                            slot=HexStr(slot),
                            new_value=HexStr(value) if value else None,
                            address=ChecksumAddress(addr),
                        ))
                return diffs
        except Exception as e:
            logger.warning("state_diff_fetch_failed", tx_hash=tx_hash, error=str(e))
        return []

    def _parse_call_tracer(self, raw: Dict, depth: int = 0) -> CallTrace:
        """Parse callTracer output into CallTrace."""
        return CallTrace(
            type=raw.get("type", "CALL"),
            from_address=ChecksumAddress(raw.get("from", "0x")),
            to_address=ChecksumAddress(raw["to"]) if raw.get("to") else None,
            value=int(raw.get("value", "0x0"), 16) if isinstance(raw.get("value"), str) else 0,
            gas=int(raw.get("gas", "0x0"), 16) if isinstance(raw.get("gas"), str) else 0,
            gas_used=int(raw.get("gasUsed", "0x0"), 16) if isinstance(raw.get("gasUsed"), str) else 0,
            input=HexStr(raw.get("input", "0x")),
            output=HexStr(raw.get("output", "0x")),
            error=raw.get("error"),
            calls=[self._parse_call_tracer(c, depth + 1) for c in raw.get("calls", [])],
        )

    async def enrich_transaction(self, tx: Transaction, chain_id: int = 1) -> Transaction:
        """Add trace and state diff to a transaction."""
        trace_raw = await self.fetch_trace(tx.hash, chain_id)
        if trace_raw:
            tx.trace = self._parse_call_tracer(trace_raw)
            tx.state_diffs = await self.fetch_state_diff(tx.hash, chain_id)
        return tx
